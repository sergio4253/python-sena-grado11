/* Áreas de la prueba Saber 11 y su peso en el puntaje global */
const AREAS={
  mat:{n:'Matemáticas',c:'#336699',w:3,i:'target'},
  lec:{n:'Lectura crítica',c:'#2F8F83',w:3,i:'book'},
  soc:{n:'Sociales y ciudadanas',c:'#D9902F',w:3,i:'users'},
  cie:{n:'Ciencias naturales',c:'#5FAE4A',w:3,i:'bolt'},
  ing:{n:'Inglés',c:'#8B6BC7',w:1,i:'chat'}
};
const AREA_KEYS=['mat','lec','soc','cie','ing'];
