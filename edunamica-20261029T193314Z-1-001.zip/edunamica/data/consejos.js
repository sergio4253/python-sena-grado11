/* Consejos y lista del día del examen */
const TIPS={
 before:[
  ['calendar','Define tu fecha y trabaja hacia atrás','Pon la fecha de tu examen en «Mi plan». Edunámica reparte las semanas en fases: base, refuerzo, simulacros y recta final.'],
  ['target','Entrena primero lo más débil','El puntaje global pesa Matemáticas, Lectura crítica, Sociales y Ciencias con 3 y Inglés con 1. Mejorar un área débil de peso 3 rinde más que pulir una fuerte.'],
  ['flame','Veinte minutos diarios valen más que tres horas el domingo','La constancia gana. Mantén tu racha y completa el reto diario.'],
  ['clock','Haz simulacros con reloj','Practicar con tiempo real te enseña a decidir cuándo dejar una pregunta y avanzar.'],
  ['book','Revisa cada error','Cada pregunta fallada tiene una explicación. Usa «Repasar mis errores» hasta que aciertes.']],
 during:[
  ['check','Lee bien lo que preguntan','Muchos errores vienen de responder otra cosa. Subraya la palabra clave: «NO», «excepto», «principalmente».'],
  ['x','Elimina primero','Descarta las dos opciones menos probables. Tus probabilidades pasan de 25 % a 50 %.'],
  ['flag','Marca y sigue','Si una pregunta te atasca más de dos minutos, márcala y continúa. Vuelve al final.'],
  ['doc','Pasa tus respuestas con cuidado','Revisa que la respuesta marcada corresponda a la pregunta que estás contestando.'],
  ['bolt','Responde todo','No hay un descuento por respuestas incorrectas. Deja una opción marcada en cada pregunta.']],
 areas:[
  ['target','Matemáticas','Dibuja, estima y comprueba reemplazando. Si la cuenta es larga, probablemente hay un camino más corto.'],
  ['book','Lectura crítica','Primero la pregunta, luego el texto. Identifica la intención del autor y desconfía de opciones muy extremas.'],
  ['users','Sociales y ciudadanas','Identifica a los actores y sus intereses. Prefiere respuestas que respeten derechos y usen el diálogo.'],
  ['bolt','Ciencias naturales','Describe la gráfica o la situación con tus palabras antes de mirar las opciones.'],
  ['chat','Inglés','No traduzcas todo. Busca palabras clave, conectores y marcas de tiempo.']]
};
const EXAM_DAY=[
 'Documento de identidad','Citación impresa o guardada, con el sitio y la hora','Lápiz, borrador y sacapuntas (revisa en tu citación qué elementos están permitidos)',
 'Llegar con tiempo de sobra','Desayunar bien y llevar agua si está permitido','Dormir bien la noche anterior','Ropa cómoda, por capas','Confiar en lo que ya practicaste'
];
