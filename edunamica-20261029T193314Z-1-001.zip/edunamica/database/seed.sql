-- Datos iniciales de Edunámica (generado desde data/*.js). Ejecutar después de schema.sql
BEGIN;
INSERT INTO areas(code,name,weight,color) VALUES ('mat','Matemáticas',3,'#336699');
INSERT INTO areas(code,name,weight,color) VALUES ('lec','Lectura crítica',3,'#2F8F83');
INSERT INTO areas(code,name,weight,color) VALUES ('soc','Sociales y ciudadanas',3,'#D9902F');
INSERT INTO areas(code,name,weight,color) VALUES ('cie','Ciencias naturales',3,'#5FAE4A');
INSERT INTO areas(code,name,weight,color) VALUES ('ing','Inglés',1,'#8B6BC7');
INSERT INTO passages(id,body) VALUES ('p1','En los últimos años, el barrio La Esperanza pasó de ser un lugar donde los vecinos casi no se conocían a un espacio de encuentro. Todo comenzó cuando un grupo de jóvenes convirtió un lote abandonado en una huerta comunitaria. Hoy, las familias intercambian semillas, organizan mercados y, sobre todo, han aprendido a resolver sus diferencias conversando. La huerta produce verduras, pero su mayor cosecha ha sido la confianza.');
INSERT INTO passages(id,body) VALUES ('p2','Algunos sostienen que los celulares deberían prohibirse en las aulas porque distraen. Sin embargo, prohibir no enseña a usar. Si el colegio incorpora el celular como herramienta, para consultar, calcular o grabar una exposición, el estudiante aprende a distinguir cuándo sirve y cuándo estorba. La prohibición total soluciona el síntoma, pero no forma criterio.');
INSERT INTO passages(id,body) VALUES ('p3','La quinua es un grano originario de los Andes. Contiene los nueve aminoácidos esenciales, lo que la hace muy valorada en la nutrición. Aunque durante siglos fue desplazada por el trigo y el arroz, hoy su cultivo resurge: la FAO declaró 2013 como el Año Internacional de la Quinua.');
INSERT INTO passages(id,body) VALUES ('p4','—No pienso trabajar este verano —dijo la cigarra—. Prefiero cantar.
Cuando llegó el invierno, la cigarra tocó a la puerta de la hormiga y le pidió comida. La hormiga la miró y respondió: —Cantaste todo el verano, ahora baila.');
INSERT INTO passages(id,body) VALUES ('p5','AVISO A LOS USUARIOS: A partir del 1 de marzo, la biblioteca atenderá de lunes a sábado, de 8 a. m. a 6 p. m. Los domingos permanecerá cerrada. El préstamo de libros será por ocho días y podrá renovarse una sola vez.');
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m1','mat',9,1,2019,NULL,'Una camiseta cuesta $40.000 y tiene un descuento del 25 %. ¿Cuánto se paga por ella?','El 25 % de 40.000 es 10.000. Se paga 40.000 − 10.000 = $30.000.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m1',0,'$10.000',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m1',1,'$30.000',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m1',2,'$35.000',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m1',3,'$15.000',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m2','mat',9,1,2021,NULL,'Si 3x + 5 = 20, ¿cuál es el valor de x?','Restamos 5 a ambos lados: 3x = 15. Dividimos entre 3: x = 5. Verifica: 3(5) + 5 = 20.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m2',0,'3',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m2',1,'5',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m2',2,'7',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m2',3,'15',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m3','mat',10,2,2021,NULL,'Un tren recorre 180 km en 2,5 horas a velocidad constante. ¿Cuántos kilómetros recorrerá en 4 horas?','Velocidad = 180 ÷ 2,5 = 72 km/h. En 4 horas: 72 × 4 = 288 km.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m3',0,'250 km',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m3',1,'288 km',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m3',2,'300 km',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m3',3,'320 km',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m4','mat',10,2,2022,NULL,'En una bolsa hay 4 balotas rojas, 6 azules y 5 verdes. Si se saca una al azar, ¿cuál es la probabilidad de que NO sea azul?','Hay 15 balotas. Las que no son azules son 4 + 5 = 9. Probabilidad: 9/15 = 3/5.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m4',0,'2/5',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m4',1,'3/5',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m4',2,'1/3',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m4',3,'4/15',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m5','mat',11,2,2023,NULL,'La media de 5 datos es 10. Si se agrega un sexto dato igual a 22, ¿cuál es la nueva media?','La suma original es 5 × 10 = 50. Con el nuevo dato: 72. La nueva media es 72 ÷ 6 = 12.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m5',0,'11',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m5',1,'12',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m5',2,'13',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m5',3,'16',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m6','mat',11,3,2024,NULL,'Para la función f(x) = x² − 4x + 3, ¿cuáles son las coordenadas del vértice de su parábola?','El vértice está en x = −b/(2a) = 4/2 = 2. Entonces f(2) = 4 − 8 + 3 = −1. Vértice: (2, −1).');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m6',0,'(2, −1)',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m6',1,'(−2, −1)',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m6',2,'(2, 1)',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m6',3,'(4, 3)',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m7','mat',9,2,2019,NULL,'¿Cuál es el área de un triángulo con base de 12 cm y altura de 7 cm?','Área = (base × altura) ÷ 2 = (12 × 7) ÷ 2 = 42 cm². Olvidar dividir entre 2 lleva a 84.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m7',0,'84 cm²',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m7',1,'42 cm²',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m7',2,'19 cm²',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m7',3,'36 cm²',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m8','mat',10,3,2025,NULL,'Un cultivo de bacterias se duplica cada hora. Si empieza con 500 bacterias, ¿cuántas habrá después de 4 horas?','Cada hora se multiplica por 2: 500 × 2⁴ = 500 × 16 = 8.000.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m8',0,'2.000',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m8',1,'4.000',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m8',2,'8.000',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m8',3,'16.000',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m9','mat',11,3,2022,NULL,'Dos números suman 30 y su diferencia es 6. ¿Cuál es el número mayor?','Si x es el mayor: x + (x − 6) = 30 → 2x = 36 → x = 18. El menor es 12.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m9',0,'12',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m9',1,'16',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m9',2,'18',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m9',3,'24',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('m10','mat',10,1,2021,NULL,'En un mapa con escala 1:50.000, dos ciudades están a 3 cm. ¿Qué distancia real hay entre ellas?','3 cm × 50.000 = 150.000 cm = 1.500 m = 1,5 km.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m10',0,'150 m',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m10',1,'1,5 km',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m10',2,'15 km',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('m10',3,'3 km',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l1','lec',9,1,2019,'p1','En el texto, la frase «su mayor cosecha ha sido la confianza» quiere decir que','Es una metáfora: la confianza se compara con una cosecha para decir que, más allá de las verduras, el mayor resultado fue la unión entre vecinos.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l1',0,'la huerta produce más confianza que verduras en cantidad medible',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l1',1,'el logro más importante de la huerta fue fortalecer los lazos entre vecinos',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l1',2,'los vecinos ya confiaban entre sí antes de que existiera la huerta',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l1',3,'la confianza se vende en los mercados del barrio',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l2','lec',9,2,2021,'p1','La primera oración del texto cumple la función de','Dice que el barrio «pasó de» una situación «a» otra: establece un contraste antes y después que el resto del texto explica.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l2',0,'definir qué es una huerta comunitaria',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l2',1,'contrastar cómo era el barrio antes con cómo es ahora',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l2',2,'criticar a los vecinos por su indiferencia',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l2',3,'anunciar un mercado próximo',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l3','lec',10,2,2022,'p2','¿Cuál es la tesis del autor sobre los celulares en el colegio?','El autor rechaza la prohibición total («prohibir no enseña a usar») y propone incorporar el celular para formar criterio.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l3',0,'Deben prohibirse por completo',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l3',1,'No distraen a ningún estudiante',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l3',2,'Es mejor enseñar a usarlos con criterio que prohibirlos',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l3',3,'Solo los profesores deberían usarlos',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l4','lec',11,3,2024,'p2','Cuando el autor dice que la prohibición «soluciona el síntoma, pero no forma criterio», sugiere que prohibir','«Síntoma» es lo visible (la distracción). «Criterio» es la capacidad de decidir. Prohibir quita lo primero, pero no desarrolla lo segundo.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l4',0,'elimina el problema de raíz y por eso es suficiente',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l4',1,'atiende lo superficial sin enseñar a decidir cuándo usar el celular',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l4',2,'es una medida que los estudiantes siempre prefieren',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l4',3,'no tiene ningún efecto sobre la distracción',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l5','lec',10,2,2023,'p3','Del texto se puede inferir que, antes de su resurgimiento actual, el cultivo de la quinua','El texto dice que fue «desplazada» durante siglos y que ahora «resurge». Eso implica que había perdido terreno.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l5',0,'había perdido espacio frente al trigo y al arroz',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l5',1,'era el más extendido del mundo',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l5',2,'era desconocido en los Andes',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l5',3,'estaba prohibido por la FAO',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l6','lec',9,1,2021,'p3','Según el texto, la quinua es originaria de','La primera oración lo dice de forma directa: es un grano originario de los Andes.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l6',0,'Asia',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l6',1,'Los Andes',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l6',2,'África',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l6',3,'Europa',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l7','lec',10,2,2025,'p4','El texto anterior es una fábula porque','Una fábula es un relato corto con personajes (aquí animales) que transmite una moraleja.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l7',0,'presenta datos estadísticos sobre el verano',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l7',1,'narra una historia breve con personajes que dejan una enseñanza',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l7',2,'describe un paisaje sin personajes',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l7',3,'argumenta a favor de una ley',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l8','lec',11,3,2021,'p4','La respuesta de la hormiga, «Cantaste todo el verano, ahora baila», tiene un tono','La hormiga retoma lo que hizo la cigarra (cantar) y lo usa en su contra («ahora baila») para reprocharle. Eso es ironía.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l8',0,'agradecido',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l8',1,'ingenuo',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l8',2,'irónico',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l8',3,'temeroso',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l9','lec',9,1,2022,'p5','¿Cuál de estos datos NO aparece en el aviso?','El aviso da horario, cierre de domingos y plazo de préstamo. No menciona ninguna multa.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l9',0,'El horario de atención',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l9',1,'El plazo de préstamo',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l9',2,'El valor de la multa por retraso',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l9',3,'El día en que la biblioteca está cerrada',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('l10','lec',10,2,2023,'p5','El propósito principal del aviso es','Es un texto informativo: comunica horarios y reglas de préstamo desde una fecha determinada.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l10',0,'convencer al lector de leer más',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l10',1,'informar cambios en el servicio de la biblioteca',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l10',2,'narrar la historia de la biblioteca',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('l10',3,'pedir donaciones de libros',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s1','soc',9,1,2019,NULL,'Una persona considera que su EPS le negó un tratamiento urgente y vulneró su derecho a la salud. ¿Qué mecanismo le permite pedir protección inmediata a un juez?','La acción de tutela protege derechos fundamentales y el juez debe resolverla en un plazo muy corto.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s1',0,'Referendo',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s1',1,'Acción de tutela',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s1',2,'Revocatoria del mandato',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s1',3,'Cabildo abierto',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s2','soc',9,1,2021,NULL,'¿Qué mecanismo de participación permite a los ciudadanos retirar del cargo a un alcalde antes de que termine su periodo?','La revocatoria del mandato es el mecanismo por el cual los votantes deciden si un gobernante o alcalde termina su periodo.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s2',0,'Plebiscito',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s2',1,'Consulta popular',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s2',2,'Revocatoria del mandato',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s2',3,'Iniciativa legislativa',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s3','soc',10,2,2021,NULL,'¿Qué rama del poder público tiene como función principal hacer las leyes?','El Congreso de la República (Senado y Cámara de Representantes) hace parte de la rama legislativa.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s3',0,'Ejecutiva',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s3',1,'Judicial',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s3',2,'Legislativa',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s3',3,'Electoral',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s4','soc',10,2,2022,NULL,'La separación de poderes en un Estado democrático busca principalmente','Al repartir funciones entre ramas, cada una controla a las otras. Así se evitan abusos de poder.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s4',0,'que una sola persona tome todas las decisiones',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s4',1,'evitar la concentración del poder mediante controles entre ramas',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s4',2,'eliminar el voto popular',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s4',3,'que los jueces escriban las leyes',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s5','soc',10,2,2023,NULL,'Un estudiante es excluido de actividades del colegio por su acento regional. ¿Qué derecho se está vulnerando principalmente?','Excluir a alguien por su origen o forma de hablar es discriminación, y vulnera la igualdad ante la ley.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s5',0,'El derecho a la propiedad',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s5',1,'El derecho a la igualdad y a no ser discriminado',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s5',2,'El derecho al voto',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s5',3,'El derecho de asociación sindical',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s6','soc',11,3,2024,NULL,'Una empresa vierte residuos al río de una comunidad y afecta a cientos de familias. ¿Qué acción es la más adecuada para proteger un derecho colectivo como el ambiente sano?','Las acciones populares protegen derechos e intereses colectivos, como el ambiente sano. La tutela suele usarse para derechos fundamentales de personas concretas.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s6',0,'Acción de tutela individual',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s6',1,'Acción popular',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s6',2,'Derecho de petición para un solo vecino',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s6',3,'Habeas corpus',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s7','soc',11,2,2025,NULL,'La Constitución Política de 1991 fue redactada por','Se convocó una Asamblea Nacional Constituyente, elegida por los ciudadanos, que redactó la nueva Constitución.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s7',0,'un golpe de Estado',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s7',1,'una Asamblea Nacional Constituyente elegida por voto popular',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s7',2,'un decreto del presidente',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s7',3,'un tratado internacional',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s8','soc',10,1,2019,NULL,'En Colombia, la cordillera de los Andes se divide en tres ramales llamados','Los Andes colombianos se dividen en las cordilleras Occidental, Central y Oriental.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s8',0,'Occidental, Central y Oriental',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s8',1,'Norte, Centro y Sur',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s8',2,'Caribe, Andina y Pacífica',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s8',3,'Amazónica, Insular y Llanera',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s9','soc',11,3,2021,NULL,'Un alcalde afirma que un proyecto minero traerá empleo. Una comunidad afirma que contaminará su agua. ¿Qué pregunta ayuda mejor a analizar el conflicto?','Analizar perspectivas implica identificar intereses y consecuencias para cada actor, no quién es más popular o ruidoso.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s9',0,'¿Quién habla más fuerte en los medios?',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s9',1,'¿Qué intereses, beneficios y consecuencias tiene cada actor?',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s9',2,'¿Cuál de los dos es más popular?',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s9',3,'¿Cuánto tiempo lleva en el cargo el alcalde?',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('s10','soc',9,2,2023,NULL,'Dos compañeros discuten por el uso de la cancha. ¿Cuál es una forma pacífica de resolver el conflicto?','La mediación busca que las partes lleguen a un acuerdo con ayuda de alguien imparcial.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s10',0,'Que el más fuerte decida',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s10',1,'Ignorar el problema hasta que desaparezca',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s10',2,'Dialogar con ayuda de un tercero neutral que medie',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('s10',3,'Quejarse en redes sociales',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c1','cie',9,1,2019,NULL,'¿Qué organelo de la célula se encarga principalmente de producir energía en forma de ATP?','Las mitocondrias producen la mayor parte del ATP, la «moneda de energía» de la célula.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c1',0,'Núcleo',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c1',1,'Ribosoma',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c1',2,'Mitocondria',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c1',3,'Vacuola',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c2','cie',9,1,2021,NULL,'¿Cuál de las siguientes es una mezcla homogénea?','En una mezcla homogénea no se distinguen sus componentes a simple vista. El agua con sal disuelta forma una sola fase.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c2',0,'Agua con arena',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c2',1,'Ensalada de frutas',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c2',2,'Agua con sal disuelta',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c2',3,'Aceite y agua',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c3','cie',10,2,2021,NULL,'Un carro de 1.000 kg acelera a 2 m/s². ¿Cuál es la fuerza neta que actúa sobre él?','Segunda ley de Newton: F = m × a = 1.000 × 2 = 2.000 N.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c3',0,'500 N',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c3',1,'1.000 N',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c3',2,'2.000 N',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c3',3,'4.000 N',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c4','cie',10,2,2022,NULL,'Se cruzan dos individuos heterocigotos (Aa × Aa). ¿Qué porcentaje de la descendencia se espera con genotipo aa?','El cruce produce AA, Aa, Aa y aa. Uno de cuatro es aa: 25 %.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c4',0,'0 %',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c4',1,'25 %',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c4',2,'50 %',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c4',3,'75 %',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c5','cie',10,2,2023,NULL,'¿Cuántas veces más ácida es una solución de pH 3 que una de pH 5?','Cada unidad de pH equivale a un factor de 10. Con dos unidades de diferencia: 10 × 10 = 100 veces.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c5',0,'2 veces',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c5',1,'10 veces',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c5',2,'100 veces',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c5',3,'1.000 veces',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c6','cie',11,3,2024,NULL,'Si en un ecosistema desaparecen los depredadores de una población de herbívoros, lo más probable es que','Sin depredadores que regulen la población, los herbívoros crecen. Después consumen demasiada vegetación y aparecen problemas de alimento.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c6',0,'los herbívoros aumenten y luego agoten la vegetación',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c6',1,'la vegetación crezca sin límite',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c6',2,'los herbívoros desaparezcan de inmediato',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c6',3,'no ocurra ningún cambio',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c7','cie',11,2,2025,NULL,'Un objeto se mueve con velocidad constante. ¿Cómo es su gráfica de posición contra tiempo?','Con velocidad constante, la posición cambia en la misma cantidad por unidad de tiempo: una recta con pendiente igual a la velocidad.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c7',0,'Una línea horizontal',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c7',1,'Una línea recta inclinada',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c7',2,'Una parábola',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c7',3,'Una curva que se detiene',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c8','cie',10,1,2021,NULL,'¿Qué gas liberan las plantas durante la fotosíntesis?','Con luz, las plantas usan CO₂ y agua para producir glucosa y liberan oxígeno.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c8',0,'Dióxido de carbono',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c8',1,'Nitrógeno',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c8',2,'Oxígeno',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c8',3,'Hidrógeno',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c9','cie',11,3,2022,NULL,'Una pelota cae libremente (sin considerar la fricción del aire). Durante la caída','Al bajar pierde altura (menos energía potencial) y gana velocidad (más energía cinética). La suma se conserva.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c9',0,'su energía potencial aumenta y la cinética disminuye',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c9',1,'su energía potencial disminuye y la cinética aumenta',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c9',2,'ambas energías aumentan',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c9',3,'ambas energías disminuyen',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('c10','cie',9,2,2019,NULL,'Los elementos de un mismo grupo (columna) de la tabla periódica tienen propiedades químicas parecidas porque','Las propiedades químicas dependen sobre todo de los electrones de la última capa (valencia), que coinciden en un mismo grupo.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c10',0,'tienen el mismo número de protones',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c10',1,'tienen el mismo número de electrones de valencia',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c10',2,'tienen la misma masa',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('c10',3,'están en el mismo estado físico',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i1','ing',9,1,2019,NULL,'She ____ to school every day.','En presente simple, con she, he o it, el verbo lleva -s o -es: «goes».');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i1',0,'go',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i1',1,'goes',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i1',2,'going',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i1',3,'gone',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i2','ing',9,1,2021,NULL,'A library is a place where you can','Library significa biblioteca. Allí se pueden pedir libros prestados (borrow books).');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i2',0,'borrow books',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i2',1,'buy shoes',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i2',2,'watch a soccer game',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i2',3,'cook dinner',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i3','ing',10,2,2021,NULL,'Anna: «Would you like some coffee?»  Tom: «____»','«Would you like…?» es una oferta. La respuesta natural es «Yes, please» o «No, thank you».');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i3',0,'Yes, I am.',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i3',1,'Yes, please.',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i3',2,'I like it very much to.',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i3',3,'No, I don''t please.',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i4','ing',10,2,2022,NULL,'If it rains tomorrow, we ____ at home.','Primer condicional: If + presente simple, will + verbo. Habla de una posibilidad real en el futuro.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i4',0,'stayed',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i4',1,'will stay',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i4',2,'staying',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i4',3,'would stayed',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i5','ing',10,2,2023,NULL,'A sign says: «NO ENTRY. AUTHORIZED PERSONNEL ONLY.» Who can go in?','«Authorized personnel only» significa que solo puede entrar el personal autorizado.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i5',0,'Everyone',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i5',1,'Only people with permission',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i5',2,'Only children',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i5',3,'Nobody, ever',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i6','ing',11,2,2024,NULL,'I haven''t seen him ____ last Monday.','Con present perfect, «since» va con un punto en el tiempo (last Monday). «For» va con una duración.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i6',0,'for',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i6',1,'since',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i6',2,'during',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i6',3,'from',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i7','ing',11,3,2025,NULL,'«Despite the heavy rain, the match went ahead.» This means that','«Despite» expresa contraste: a pesar de la lluvia, el partido se jugó.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i7',0,'the match was cancelled',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i7',1,'the match took place even though it rained',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i7',2,'the rain started after the match',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i7',3,'nobody went to the match',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i8','ing',11,2,2022,NULL,'The report ____ by the team before Friday.','Voz pasiva con modal: modal + be + participio (must be finished).');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i8',0,'must finish',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i8',1,'must be finished',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i8',2,'must finishing',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i8',3,'must to finish',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i9','ing',9,2,2021,NULL,'The meeting is ____ 3 p.m.','Para horas exactas se usa «at»: at 3 p.m., at noon, at midnight.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i9',0,'in',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i9',1,'on',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i9',2,'at',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i9',3,'by',0);
INSERT INTO questions(id,area_code,grade,difficulty,reference_year,passage_id,statement,explanation) VALUES ('i10','ing',11,3,2023,NULL,'An email begins: «I am writing to complain about the late delivery of my order.» The main purpose of the email is to','«To complain» es quejarse. El propósito es expresar inconformidad por la entrega tardía.');
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i10',0,'thank the company',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i10',1,'express dissatisfaction',1);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i10',2,'ask for a job',0);
INSERT INTO question_options(question_id,position,body,is_correct) VALUES ('i10',3,'invite a friend',0);
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('lm1','mat','Porcentajes y proporcionalidad',6,'Un porcentaje es una fracción de 100. Para calcular el 25 % de una cantidad, multiplica por 0,25 o divide entre 4.
- Descuento: precio final = precio × (1 − descuento).
- Aumento: precio final = precio × (1 + aumento).
- Regla de tres directa: si una cantidad crece, la otra crece en la misma proporción.
Truco ICFES: antes de calcular, estima. Si te piden el 10 % de 480, la respuesta debe ser cercana a 48. Descarta opciones absurdas.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('lm2','mat','Funciones y gráficas',7,'Una función relaciona cada valor de x con un único valor de y.
- Lineal: y = mx + b. «m» es la pendiente (qué tanto sube) y «b» el corte con el eje y.
- Cuadrática: y = ax² + bx + c. Su gráfica es una parábola. El vértice está en x = −b/2a.
- Exponencial: y = a·bˣ. Crece o decae multiplicando, no sumando.
Truco ICFES: reemplaza valores. Si dudas entre dos gráficas, prueba un punto sencillo como x = 0 o x = 1.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('lm3','mat','Probabilidad y estadística básica',6,'Probabilidad = casos favorables ÷ casos posibles. Siempre está entre 0 y 1.
- Evento contrario: P(no A) = 1 − P(A).
- Media: suma de datos ÷ cantidad de datos. Mediana: el dato del centro ordenado. Moda: el que más se repite.
- Si agregas un dato mayor que la media, la media sube.
Truco ICFES: lee con calma qué se pide (media, mediana o moda) antes de operar.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('ll1','lec','Cómo encontrar la idea principal',5,'La idea principal es lo que el texto quiere comunicar. El resto son ejemplos, datos o detalles.
- Pregúntate: si tuviera que resumir el texto en una frase, ¿cuál sería?
- Busca conectores de contraste («sin embargo», «pero»). Lo importante suele venir después.
- Lee la pregunta primero y luego el texto. Así subrayas con un objetivo.
Truco ICFES: las opciones que repiten una palabra del texto pero cambian el sentido suelen ser trampas.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('ll2','lec','Inferir y leer entre líneas',6,'Inferir es concluir algo que el texto no dice de forma directa, pero que se deduce de lo que dice.
- Fíjate en verbos como «resurge», «desplazó», «aún»: sugieren un antes y un después.
- Distingue ironía, metáfora y sentido literal. Pregúntate qué quiere lograr el autor con esa frase.
- Una buena inferencia siempre se puede apoyar en una frase del texto.
Truco ICFES: si una opción necesita información que no está en el texto, probablemente es incorrecta.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('ls1','soc','Constitución de 1991 y mecanismos de protección',7,'Colombia es un Estado social de derecho. La Constitución de 1991 reconoce derechos y crea mecanismos para defenderlos.
- Acción de tutela: protege derechos fundamentales de una persona.
- Acción popular: protege derechos colectivos (ambiente sano, espacio público).
- Derecho de petición: pedir información o solicitar algo a una autoridad.
- Participación: voto, plebiscito, referendo, consulta popular, revocatoria del mandato, cabildo abierto, iniciativa legislativa.
Truco ICFES: pregúntate si el caso afecta a una persona o a toda una comunidad.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('ls2','soc','Competencias ciudadanas: analizar perspectivas',5,'Muchas preguntas presentan un conflicto entre dos o más actores. No piden tu opinión, piden análisis.
- Identifica quién habla, qué quiere y qué le preocupa.
- Diferencia hechos (se pueden comprobar) de opiniones (juicios de valor).
- Busca la opción que respete derechos de todos y use el diálogo.
Truco ICFES: descarta opciones que justifiquen la violencia, la discriminación o ignorar a una de las partes.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('lc1','cie','Leer gráficas y variables',6,'En ciencias naturales, la mitad del trabajo es interpretar datos.
- Identifica qué hay en cada eje y cuáles son las unidades.
- Variable independiente: la que cambias. Dependiente: la que mides.
- Una recta inclinada indica cambio constante. Una horizontal, que no hay cambio.
Truco ICFES: antes de leer las opciones, describe la gráfica con tus propias palabras.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('lc2','cie','Energía, fuerza y movimiento',7,'- Segunda ley de Newton: F = m·a.
- Energía cinética: la del movimiento. Energía potencial: la que depende de la altura o posición.
- Sin fricción, la energía mecánica total se conserva: lo que pierde una, lo gana la otra.
- Velocidad constante significa aceleración cero y fuerza neta cero.
Truco ICFES: dibuja el esquema y marca las fuerzas con flechas.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('li1','ing','Tiempos verbales que más aparecen',6,'- Presente simple: hábitos y hechos. She works. They play.
- Presente continuo: acciones en este momento. He is reading.
- Pasado simple: acciones terminadas. We visited Cali last year.
- Present perfect: puente entre pasado y presente. I have lived here for five years.
- Primer condicional: If it rains, we will stay.
Truco ICFES: busca marcas de tiempo (yesterday, since, for, tomorrow). Te dicen el tiempo verbal.');
INSERT INTO lessons(id,area_code,title,minutes,body) VALUES ('li2','ing','Estrategias para las partes de lectura',5,'El examen de inglés incluye avisos, vocabulario, conversaciones, lectura y gramática en contexto.
- En avisos y letreros, pregúntate dónde verías ese mensaje y qué quiere que hagas.
- En conversaciones, identifica si es una oferta, una invitación o una petición.
- No traduzcas palabra por palabra. Busca el sentido general y las palabras clave.
Truco ICFES: la palabra que no conoces casi nunca es la clave. Sigue leyendo.');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2019','cie',NULL,'https://universate.co/wp-content/uploads/2023/12/cuadernillo-de-preguntas-saber-11-ciencias-naturales-2019.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2019','mat',NULL,'https://universate.co/wp-content/uploads/2023/12/cuadernillo-de-preguntas-saber-11-matematicas-2019.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2019','soc',NULL,'https://universate.co/wp-content/uploads/2023/12/cuadernillo-de-preguntas-saber-11-sociales-y-ciudadanas-2019.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2019','lec',NULL,'https://universate.co/wp-content/uploads/2023/12/cuadernillo-de-preguntas-saber-11-lectura-critica-2019.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2019','ing',NULL,'https://universate.co/wp-content/uploads/2023/12/cuadernillo-de-preguntas-ingles-saber-11-2019.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2021','cie',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Ciencias_Naturales-11-2021.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2021','mat',NULL,'https://universate.co/wp-content/uploads/2023/12/Matematicas-Grado.11-2021.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2021','soc',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-SocialesyCiudadanas-11-2021.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2021','lec',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-LecturaCritica-11-2021.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2021','ing',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Ingles-11-2021.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2022','cie',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Ciencias_Naturales-11-2022.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2022','mat',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Matematicas-11-2022.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2022','soc',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-SocialesyCiudadanas-11-2022.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2022','lec',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-LecturaCritica-11-2022.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2022','ing',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Ingles-11-2022.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2023','cie',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Ciencias_Naturales-11-1-1.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2023','mat',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Matematicas-11-1.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2023','soc',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-SocialesyCiudadanas-11-1.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2023','lec',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-LecturaCritica-11-1.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2023','ing',NULL,'https://universate.co/wp-content/uploads/2023/12/Cuadernillo-Ingles-11-1.pdf');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2025',NULL,'Primera sesión: Matemáticas, Lectura crítica, Sociales y Ciencias','https://drive.google.com/file/d/1JoB0hEnSL91vPOu1jrh1SdMndSkO4SJD/view?usp=drivesdk');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2025',NULL,'Segunda sesión: Sociales, Matemáticas, Ciencias e Inglés','https://drive.google.com/file/d/1W9K_4UuyJnbm0idL-QBgZxm1ZvkbGUUV/view?usp=drivesdk');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2024-2',NULL,'Primera sesión: Matemáticas, Lectura crítica, Sociales y Ciencias','https://drive.google.com/file/d/1rbWAfzITMJbFy1vsXCanUKIXRiIY_WoH/view');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2024-2',NULL,'Segunda sesión: Sociales, Matemáticas, Ciencias e Inglés','https://drive.google.com/file/d/1XHWetcFXSNL_NS1Ht2N01rOyY1Y0GToN/view?usp=drivesdk');
INSERT INTO official_booklets(year,area_code,session,url) VALUES ('2024-1',NULL,'Primera sesión: Matemáticas, Lectura crítica, Sociales y Ciencias','https://drive.google.com/file/d/12KmtcJHtE29bZlYEKCyMLmj4nxl9p-bd/view');
COMMIT;
