"""
Exportador y Unificador de Base de Datos para Edunámica
Genera un archivo Excel (.xlsx) completo y estilizado con todas las tablas del sistema:
- Preguntas Saber 11
- Áreas evaluadas
- Lecciones
- Lecturas / Pasajes
- Jugadores / Usuarios
- Consejos
- Cuadernillos
"""

import json
import os
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, 'data', 'json')
OUTPUT_EXCEL = os.path.join(BASE_DIR, 'database', 'edunamica_database.xlsx')

def load_json(filename):
    path = os.path.join(DATA_DIR, filename)
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def build_excel():
    wb = openpyxl.Workbook()
    default_sheet = wb.active

    # Estilos profesionales inspirados en Microsoft Excel corporativo
    header_fill = PatternFill(start_color="107C41", end_color="107C41", fill_type="solid")
    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
    data_font = Font(name="Segoe UI", size=10, color="1F2937")
    thin_border = Border(
        left=Side(style='thin', color='E5E7EB'),
        right=Side(style='thin', color='E5E7EB'),
        top=Side(style='thin', color='E5E7EB'),
        bottom=Side(style='thin', color='E5E7EB')
    )
    alt_fill = PatternFill(start_color="F8FAFC", end_color="F8FAFB", fill_type="solid")

    def format_sheet(ws, title, headers, rows):
        ws.title = title
        ws.views.sheetView[0].showGridLines = True
        
        # Escribir cabeceras
        for col_num, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_num, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = thin_border
        
        ws.row_dimensions[1].height = 28

        # Escribir filas
        for row_num, row_data in enumerate(rows, 2):
            is_alt = (row_num % 2 == 0)
            ws.row_dimensions[row_num].height = 22
            for col_num, val in enumerate(row_data, 1):
                cell = ws.cell(row=row_num, column=col_num, value=val)
                cell.font = data_font
                cell.border = thin_border
                if is_alt:
                    cell.fill = alt_fill
                if isinstance(val, (int, float)):
                    cell.alignment = Alignment(horizontal="right", vertical="center")
                else:
                    cell.alignment = Alignment(horizontal="left", vertical="center")

        # Autoajuste de anchos de columna
        for col in ws.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                val_str = str(cell.value or '')
                if len(val_str) > max_len:
                    max_len = len(val_str)
            ws.column_dimensions[col_letter].width = max(14, min(max_len + 4, 70))

    # 1. PREGUNTAS
    preguntas = load_json('preguntas.json')
    q_headers = ["ID", "Área", "Grado", "Dificultad", "Año Ref.", "Pasaje ID", "Enunciado", "Opción A", "Opción B", "Opción C", "Opción D", "Opción Correcta", "Explicación"]
    q_rows = []
    letters = ['A', 'B', 'C', 'D']
    for q in preguntas:
        opts = q.get('o', [])
        c_idx = q.get('c', 0)
        correct_ltr = letters[c_idx] if 0 <= c_idx < len(letters) else str(c_idx)
        q_rows.append([
            q.get('id', ''),
            q.get('a', ''),
            q.get('g', ''),
            q.get('d', ''),
            q.get('y', ''),
            q.get('p', '') or 'N/A',
            q.get('t', ''),
            opts[0] if len(opts) > 0 else '',
            opts[1] if len(opts) > 1 else '',
            opts[2] if len(opts) > 2 else '',
            opts[3] if len(opts) > 3 else '',
            correct_ltr,
            q.get('e', '')
        ])
    ws1 = wb.create_sheet(title="Preguntas")
    format_sheet(ws1, "Preguntas", q_headers, q_rows)

    # 2. ÁREAS
    areas = load_json('areas.json')
    a_headers = ["Código", "Nombre del Área", "Peso en Puntaje", "Color Hex"]
    a_rows = []
    for item in areas:
        a_rows.append([item.get('code', ''), item.get('name', ''), item.get('weight', ''), item.get('color', '')])
    ws2 = wb.create_sheet(title="Áreas")
    format_sheet(ws2, "Áreas", a_headers, a_rows)

    # 3. LECCIONES
    lecciones = load_json('lecciones.json')
    l_headers = ["ID", "Área", "Título", "Minutos Estimados", "Contenido de la Lección"]
    l_rows = []
    for l in lecciones:
        l_rows.append([
            l.get('id', ''),
            l.get('area', '') or l.get('a', ''),
            l.get('title', ''),
            l.get('minutes', ''),
            l.get('body', '')
        ])
    ws3 = wb.create_sheet(title="Lecciones")
    format_sheet(ws3, "Lecciones", l_headers, l_rows)

    # 4. LECTURAS
    lecturas = load_json('lecturas.json')
    lec_headers = ["ID Pasaje", "Texto / Pasaje de Comprensión Lectora"]
    lec_rows = []
    for item in lecturas:
        lec_rows.append([item.get('id', ''), item.get('text', '')])
    ws4 = wb.create_sheet(title="Lecturas")
    format_sheet(ws4, "Lecturas", lec_headers, lec_rows)

    # 5. JUGADORES Y USUARIOS EJEMPLO
    jugadores = load_json('jugadores_ejemplo.json')
    u_headers = ["Nombre", "Colegio", "Grado", "XP Semanal", "Rating Elo", "Racha (Días)", "Puntaje Estimado", "Color Avatar"]
    u_rows = []
    for j in jugadores:
        u_rows.append([
            j.get('name', ''),
            j.get('school', ''),
            j.get('grade', 11),
            j.get('xp', 0),
            j.get('rating', 1050),
            j.get('streak', 0),
            j.get('score', 350),
            j.get('color', '#336699')
        ])
    ws5 = wb.create_sheet(title="Usuarios_y_Ranking")
    format_sheet(ws5, "Usuarios_y_Ranking", u_headers, u_rows)

    # 6. CONSEJOS
    consejos = load_json('consejos.json')
    c_headers = ["Etapa / Momento", "Icono", "Título del Consejo", "Detalle de la Estrategia"]
    c_rows = []
    tips = consejos.get('tips', {})
    for item in tips.get('before', []):
        c_rows.append(["Antes del Examen (Preparación)", item[0], item[1], item[2]])
    for item in tips.get('during', []):
        c_rows.append(["Durante el Examen", item[0], item[1], item[2]])
    for item in tips.get('stress', []):
        c_rows.append(["Control de Estrés", item[0], item[1], item[2]])
    ws6 = wb.create_sheet(title="Consejos_ICFES")
    format_sheet(ws6, "Consejos_ICFES", c_headers, c_rows)

    # 7. CUADERNILLOS OFICIALES
    cuadernillos = load_json('cuadernillos.json')
    cuad_headers = ["Año", "Área", "Tipo / Sesión", "URL Oficial ICFES"]
    cuad_rows = []
    por_area = cuadernillos.get('por_area', {})
    for year, areas_dict in por_area.items():
        for area_code, url in areas_dict.items():
            cuad_rows.append([year, area_code, "Cuadernillo por Área", url])
    for item in cuadernillos.get('por_sesion', []):
        cuad_rows.append([item.get('year', ''), "Todas las Áreas", item.get('title', ''), item.get('url', '')])
    ws7 = wb.create_sheet(title="Cuadernillos")
    format_sheet(ws7, "Cuadernillos", cuad_headers, cuad_rows)

    wb.remove(default_sheet)
    wb.save(OUTPUT_EXCEL)
    print(f"Base de datos unificada en Excel generada con éxito en: {OUTPUT_EXCEL}")

if __name__ == '__main__':
    build_excel()
