/* Interfaz compartida: avisos, ventanas, estructura (menú lateral) y arranque de página */
function toast(msg,kind='',ms=3200){
  const box=$('#toasts');if(!box)return;const t=document.createElement('div');t.className='toast '+kind;t.innerHTML=msg;box.appendChild(t);
  setTimeout(()=>{t.classList.add('out');setTimeout(()=>t.remove(),320)},ms);
}
function modal(html){
  const m=document.createElement('div');m.className='modal';m.innerHTML=`<div class="mbox" role="dialog" aria-modal="true">${html}</div>`;document.body.appendChild(m);
  const close=()=>{m.remove();document.removeEventListener('keydown',esc_)};
  const esc_=e=>{if(e.key==='Escape')close()};document.addEventListener('keydown',esc_);
  m.addEventListener('click',e=>{if(e.target===m)close()});
  const f=$('button',m);f&&f.focus();return{el:m,close};
}
function confirmBox(msg,yesLabel,onYes){
  const m=modal(`<h3>${msg}</h3><div class="row" style="justify-content:flex-end"><button class="btn ghost" data-no>Cancelar</button><button class="btn" data-yes>${yesLabel}</button></div>`);
  $('[data-no]',m.el).onclick=m.close;$('[data-yes]',m.el).onclick=()=>{m.close();onYes()};
}
const empty=(title,text,btn='')=>`<div class="card empty"><h3>${title}</h3><p class="muted">${text}</p>${btn}</div>`;
const avatar=(name,color,s=40)=>`<span class="avatar" style="--s:${s}px;--ac:${color||'#336699'}">${esc((name||'?').trim()[0]||'?').toUpperCase()}</span>`;
const srcLine=q=>{const u=CUAD[q.y]&&CUAD[q.y][q.a];return`${ic('doc',16)}<span>Estilo Saber 11, año de referencia ${q.y}${u?` <a href="${u}" target="_blank" rel="noopener noreferrer">Ver cuadernillo oficial</a>`:''}</span>`};
const ringSVG=(pct,color='var(--brand)')=>`<svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="52" fill="none" stroke="var(--surface2)" stroke-width="12"/><circle cx="60" cy="60" r="52" fill="none" stroke="${color}" stroke-width="12" stroke-linecap="round" pathLength="100" stroke-dasharray="${clamp(pct,0,100)} 100"/></svg>`;

function updateChips(){
  const c=$('#chips');if(!c||!S.user)return;
  c.innerHTML=`<a class="chip fire" href="retos.html" title="Racha de días">${ic('flame',16)} ${streakNow()}</a><span class="chip coin" title="Monedas">${ic('coin',16)} ${S.coins}</span><a class="chip xp-l" href="logros.html" title="Nivel y XP">${ic('star',16)} Nivel ${lvl(S.xp)}, ${fmt(S.xp)} XP</a>`;
}
const head=(t,p='',extra='')=>`<div class="pagehead"><div><h1 style="font-size:clamp(1.7rem,3vw,2.4rem)">${t}</h1>${p?`<p>${p}</p>`:''}</div>${extra}</div>`;

const pg=r=>(r==='inicio'?'dashboard':r)+'.html';
const NAV=[['inicio','Inicio','home'],['plan','Mi plan','cal'],['practicar','Practicar','target'],['simulacro','Simulacro','clock'],['retos','Retos diarios','bolt'],['torneos','Torneos','trophy'],['ranking','Ranking','podium'],['cursos','Cursos','book'],['cuadernillos','Cuadernillos','doc'],['logros','Logros','medal'],['consejos','Consejos','bulb'],['edu','Asistente Edu','chat']];
const TABS=[['inicio','Inicio','home'],['practicar','Practicar','target'],['retos','Retos','bolt'],['ranking','Ranking','podium'],['edu','Edu','chat']];
const TITLES={inicio:'Inicio',plan:'Mi plan',practicar:'Practicar',simulacro:'Simulacro',retos:'Retos diarios',torneos:'Torneos',ranking:'Ranking',cursos:'Cursos',leccion:'Lección',cuadernillos:'Cuadernillos',logros:'Logros',consejos:'Consejos',edu:'Asistente Edu',perfil:'Perfil'};
function shell(){
  const u=S.user;
  return`<div class="app"><aside class="side" id="side">${logo('dashboard.html')}
   <nav aria-label="Principal">${NAV.map(([r,l,i])=>`<a href="${pg(r)}" data-r="${r}">${ic(i)}${l}</a>`).join('')}</nav>
   <div class="side-foot"><button class="btn ghost sm" id="theme">${ic('moon',16)} Cambiar tema</button>
    <a class="userchip" href="perfil.html" data-r="perfil">${avatar(u.name,u.color,38)}<span><b>${esc(u.name.split(' ')[0])}</b><small>Grado ${u.grade}, perfil</small></span></a>
    <button class="btn ghost sm" id="logout">Cerrar sesión</button></div></aside>
   <div class="scrim" id="scrim"></div>
   <div class="main"><header class="topbar"><button class="btn ghost sm menu" id="menu" aria-label="Abrir menú">${ic('menu',18)}</button><a class="logo-m" href="dashboard.html" aria-label="Inicio">${MARK}</a><div class="chips" id="chips"></div></header>
   <main id="view" tabindex="-1"></main></div>
   <nav class="tabbar" aria-label="Acceso rápido">${TABS.map(([r,l,i])=>`<a href="${pg(r)}" data-r="${r}">${ic(i,22)}${l}</a>`).join('')}</nav></div>`;
}
function bindShell(){
  const side=$('#side'),scrim=$('#scrim');
  const set=o=>{side.classList.toggle('open',o);scrim.classList.toggle('show',o)};
  $('#menu').onclick=()=>set(true);scrim.onclick=()=>set(false);
  $('#logout').onclick=logout;
  $('#theme').onclick=()=>{const dark=document.documentElement.dataset.theme==='dark'||(S.theme==='auto'&&matchMedia('(prefers-color-scheme:dark)').matches);S.theme=dark?'light':'dark';applyTheme();save()};
}
function setActive(name){
  $$('[data-r]').forEach(a=>{a.dataset.r===name?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current')});
}
/* Arranque común de las páginas internas: exige sesión, pinta el menú y llama a la vista */
function mountPage(name,fn){
  const acc=sessionUser();
  if(!acc){const cur=(location.pathname.split('/').pop()||'dashboard.html')+location.search;location.replace('login.html?next='+encodeURIComponent(cur));return}
  loadState(acc);applyTheme();
  if(typeof settleCup==='function')settleCup();
  $('#root').innerHTML=shell();bindShell();setActive(name);updateChips();
  document.title=`${TITLES[name]||'Edunámica'}, Edunámica`;
  window.scrollTo(0,0);fn($('#view'),ARG);
}
