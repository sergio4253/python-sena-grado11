/* Página: simulacro.html */
function simV(el,arg){
  const OPTS={r:[15,25,'Rápido'],e:[30,50,'Estándar'],m:[50,90,'Maratón']};
  if(arg&&OPTS[arg]){
    const [n,min]=OPTS[arg],per=Math.ceil(n/5);let qs=[];
    AREA_KEYS.forEach(a=>{const w=a==='ing'?Math.max(1,Math.round(per*.6)):per;qs.push(...pickSet(w,{area:a}))});
    qs=shuffle(qs).slice(0,n);
    return runExam(el,{title:`Simulacro ${OPTS[arg][2].toLowerCase()}`,qs,minutes:min});
  }
  const last=S.sims[S.sims.length-1];
  el.innerHTML=head('Simulacro','Preguntas de las cinco áreas, con reloj y sin retroalimentación hasta el final. Así se siente la prueba.')+`
   <div class="cols3">${Object.entries(OPTS).map(([k,[n,m,l]])=>`<div class="card acard" style="--ac:${k==='r'?'var(--lime)':k==='e'?'var(--brand)':'var(--ink)'}"><h3>${l}</h3><p class="muted">${n} preguntas en ${m} minutos.</p><a class="btn ${k==='e'?'':'ghost'}" href="simulacro.html?a=${k}">Empezar</a></div>`).join('')}</div>
   <div class="card" style="margin-top:18px"><h3>Historial</h3>${S.sims.length?`<div class="row" style="gap:24px;align-items:flex-start"><div>${spark(S.sims.map(s=>s.score).concat(S.sims.length===1?[S.sims[0].score]:[]))}</div><div class="kv"><div><b>${last.score}</b><span>Último puntaje</span></div><div><b>${Math.max(...S.sims.map(s=>s.score))}</b><span>Mejor</span></div><div><b>${S.sims.length}</b><span>Simulacros</span></div></div></div>`:'<p class="muted">Todavía no has hecho simulacros. Empieza con el rápido para medir tu nivel.</p>'}</div>
   <p class="muted" style="margin-top:14px">Consejo: elige un lugar tranquilo y no pauses el reloj. Después de entregar, revisa cada error.</p>`;
}


mountPage('simulacro',simV);
