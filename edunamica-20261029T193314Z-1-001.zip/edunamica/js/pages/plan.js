/* Página: plan.html */
const DAYN=['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
function buildPlan(){
  const p=S.plan,ws=weekStart(),wk=weekKey(),days=[];
  const wts=AREA_KEYS.map(a=>({a,w:AREAS[a].w*(115-areaScore(a))})),tw=wts.reduce((n,x)=>n+x.w,0);
  const usedL=new Set(),last=Math.max(...p.days,-1);
  for(let d=0;d<7;d++){
    const date=addDays(ws,d);if(!p.days.includes(d)){days.push({d,date,rest:true,items:[]});continue}
    const r=rng(hash(wk+'p'+d+p.min)),items=[{id:`${wk}-${d}-r`,t:'Reto diario',s:'5 preguntas, una por área',min:5,href:'retos.html'}];
    const nb=Math.max(1,Math.round((p.min-5)/25));
    for(let b=0;b<nb;b++){
      let x=r()*tw,a=wts[0].a;for(const w of wts){if(x<w.w){a=w.a;break}x-=w.w}
      const m=Math.round((p.min-5)/nb);
      if(d===last&&b===0&&p.min>=60){items.push({id:`${wk}-${d}-s`,t:'Simulacro rápido',s:'15 preguntas con reloj',min:25,href:'simulacro.html?a=r'});continue}
      const les=LESSONS.find(l=>l.a===a&&!S.lessons[l.id]&&!usedL.has(l.id));
      if(les&&b===0){usedL.add(les.id);items.push({id:`${wk}-${d}-${b}`,t:`Lección: ${les.t}`,s:AREAS[a].n,min:les.min,href:'leccion.html?a='+les.id,a});}
      else items.push({id:`${wk}-${d}-${b}`,t:`Practicar ${AREAS[a].n}`,s:`${clamp(Math.round(m/2.5),5,15)} preguntas, nivel adaptado`,min:m,href:'practicar.html?a='+a,a});
    }
    days.push({d,date,rest:false,items});
  }
  return days;
}
function planV(el){
  const p=S.plan,days=buildPlan(),dd=daysTo(S.user.exam),todayI=(new Date().getDay()+6)%7;
  const all=days.flatMap(d=>d.items),done=all.filter(i=>S.checks[i.id]).length;
  let ph=null;if(dd!=null&&dd>=0){const wl=Math.ceil(dd/7);ph=wl>12?['Construir base','Entiende los temas y practica sin presión.']:wl>=6?['Reforzar áreas débiles','Dedica más tiempo a tus puntajes más bajos.']:wl>=2?['Simulacros y ritmo','Haz simulacros con reloj y revisa cada error.']:['Recta final','Repasa errores, descansa y llega tranquilo.']}
  const wo=weakOrder();
  el.innerHTML=head('Mi plan de estudio','Se arma cada semana según tu progreso, tu tiempo y la fecha de tu examen.')+
  (ph?`<div class="phase"><div><b>${ph[0]}</b><br><span>${ph[1]}</span></div><span class="grow"></span><div style="text-align:right"><b>${dd}</b><br><span>días para tu examen</span></div></div>`:`<div class="banner">${ic('cal',26)}<div class="grow"><b>Agrega la fecha de tu examen</b><p class="muted">Con ella organizamos tu plan en fases.</p></div><a class="btn" href="perfil.html#editar">Agregar fecha</a></div>`)+`
  <div class="cols2"><section class="card"><h3>Tu disponibilidad</h3><div class="field"><label for="min">Minutos por día de estudio: <b id="mv">${p.min}</b></label><input type="range" id="min" min="30" max="180" step="15" value="${p.min}"></div>
   <div class="field"><span class="lab" id="dl">Días que estudias</span><div class="days" role="group" aria-labelledby="dl">${DAYN.map((n,i)=>`<button data-d="${i}" aria-pressed="${p.days.includes(i)}" aria-label="${n}">${n[0]}</button>`).join('')}</div></div>
   <p class="muted">Tu plan prioriza: ${wo.slice(0,2).map(a=>`<b>${AREAS[a].n}</b>`).join(' y ')}.</p></section>
   <section class="card"><h3>Progreso de la semana</h3><div class="kv"><div><b>${done}/${all.length}</b><span>Bloques cumplidos</span></div><div><b>${all.filter(i=>S.checks[i.id]).reduce((n,i)=>n+i.min,0)}</b><span>Minutos</span></div></div><div class="bar" style="margin-top:14px"><i style="width:${all.length?done/all.length*100:0}%"></i></div></section></div>
  <div class="stack" style="margin-top:16px">${days.map(d=>`<div class="plan-day ${d.rest?'rest':''} ${d.d===todayI?'today':''}"><h4><span>${DAYN[d.d]} ${d.date.getDate()}</span><span>${d.rest?'Descanso':d.items.reduce((n,i)=>n+i.min,0)+' min'}</span></h4>
   ${d.items.map(i=>`<div class="blk-i ${S.checks[i.id]?'done':''}"><input type="checkbox" id="${i.id}" ${S.checks[i.id]?'checked':''} aria-label="Marcar como hecho"><label class="t" for="${i.id}"><b>${esc(i.t)}</b><small>${esc(i.s)}, ${i.min} min</small></label><a class="btn ghost sm" href="${i.href}">Ir</a></div>`).join('')}</div>`).join('')}</div>`;
  $('#min',el).oninput=e=>{p.min=+e.target.value;$('#mv').textContent=p.min};$('#min',el).onchange=()=>{save();planV(el)};
  $$('[data-d]',el).forEach(b=>b.onclick=()=>{const i=+b.dataset.d;p.days=p.days.includes(i)?p.days.filter(x=>x!==i):[...p.days,i].sort();if(!p.days.length)p.days=[i];save();planV(el)});
  $$('.blk-i input',el).forEach(c=>c.onchange=()=>{S.checks[c.id]=c.checked;if(c.checked){addXP(5);updateChips()}save();planV(el)});
}


mountPage('plan',planV);
