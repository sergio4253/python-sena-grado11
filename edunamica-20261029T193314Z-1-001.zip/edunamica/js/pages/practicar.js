/* Página: practicar.html */
function startPractice(el,area,o){
  const grade=o.level==='all'?11:S.user.grade;
  runLearn(el,{title:area?`Práctica de ${AREAS[area].n}`:'Práctica mixta',qs:pickSet(o.n,{area,grade}),back:'practicar.html',again:()=>startPractice(el,area,o)});
}
function startDiag(el){
  const qs=[];AREA_KEYS.forEach(a=>{qs.push(...pickSet(2,{area:a}))});
  runLearn(el,{title:'Diagnóstico completado',qs:shuffle(qs),k:48,back:'dashboard.html',onEnd:r=>{S.diag=true;S.coins+=15;addXP(30);save();return`<div class="card flat" style="width:100%"><b>Tu punto de partida: ${globalScore()} de 500</b><p class="muted">Ya tienes plan personalizado. +30 XP y +15 monedas por completar el diagnóstico.</p><a class="btn lime" style="margin-top:10px" href="plan.html">Ver mi plan</a></div>`}});
}
function startReview(el){
  const qs=S.review.map(id=>QBY[id]).filter(Boolean).slice(0,10);
  if(!qs.length){el.innerHTML=empty('No tienes preguntas para repasar','Cuando falles o guardes preguntas, aparecerán aquí.',`<a class="btn" href="practicar.html">Practicar</a>`);return}
  runLearn(el,{title:'Repaso de errores',qs,back:'practicar.html',again:()=>startReview(el)});
}
function practiceV(el,arg){
  if(arg==='diagnostico')return startDiag(el);
  if(arg==='repaso')return startReview(el);
  if(arg){return startPractice(el,arg==='mix'||!AREAS[arg]?null:arg,{n:10,level:'mine'})}
  let o={n:10,level:'mine'};
  el.innerHTML=head('Practicar','Elige un área. La dificultad se ajusta a tu nivel y priorizamos preguntas que aún no has visto.')+`
   <div class="card flat stack" style="margin-bottom:18px"><div class="row"><span class="lab" style="font-weight:700">Preguntas</span><div class="seg" id="sn">${[5,10,20].map(n=>`<button aria-pressed="${o.n===n}" data-n="${n}">${n}</button>`).join('')}</div>
    <span class="lab" style="font-weight:700;margin-left:12px">Nivel</span><div class="seg" id="sl"><button data-l="mine" aria-pressed="true">Mi grado (${S.user.grade})</button><button data-l="all" aria-pressed="false">Todos los grados</button></div></div></div>
   <div class="cols3">${AREA_KEYS.map(a=>{const A=AREAS[a],acc=accArea(a);return`<div class="card acard" style="--ac:${A.c}"><h3>${ic(A.i,22)}${A.n}</h3><div><div class="row" style="justify-content:space-between"><span class="muted">Puntaje</span><b>${areaScore(a)}/100</b></div><div class="bar" style="--ac:${A.c};margin-top:6px"><i style="width:${areaScore(a)}%"></i></div></div><p class="muted" style="font-size:.9rem">${S.stats[a].t?`${S.stats[a].t} respondidas, ${acc}% de aciertos`:'Aún sin respuestas'}</p><button class="btn" data-a="${a}">Practicar</button></div>`}).join('')}
    <div class="card acard" style="--ac:var(--ink)"><h3>${ic('sliders',22)}Mixto</h3><p class="muted">Una mezcla de las cinco áreas, empezando por las que más necesitas.</p><button class="btn lime" data-a="mix">Practicar mixto</button></div>
    <div class="card acard" style="--ac:var(--coral)"><h3>${ic('repeat',22)}Repasar errores</h3><p class="muted">${S.review.length?`Tienes ${S.review.length} preguntas por repasar.`:'Aquí aparecerán tus errores y las preguntas que guardes.'}</p><button class="btn ghost" data-a="repaso" ${S.review.length?'':'disabled'}>Repasar</button></div></div>`;
  $$('#sn button',el).forEach(b=>b.onclick=()=>{o.n=+b.dataset.n;$$('#sn button',el).forEach(x=>x.setAttribute('aria-pressed',x===b))});
  $$('#sl button',el).forEach(b=>b.onclick=()=>{o.level=b.dataset.l;$$('#sl button',el).forEach(x=>x.setAttribute('aria-pressed',x===b))});
  $$('[data-a]',el).forEach(b=>b.onclick=()=>{const a=b.dataset.a;if(a==='repaso')return startReview(el);startPractice(el,a==='mix'?null:a,o)});
}


mountPage('practicar',practiceV);
