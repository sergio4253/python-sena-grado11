/* Página: cursos.html */
function coursesV(el){
  el.innerHTML=head('Cursos','Mini-lecciones de cinco a siete minutos. Cada una te da 20 XP y termina con práctica del tema.')+`<div class="cols2">${AREA_KEYS.map(a=>{const A=AREAS[a],ls=LESSONS.filter(l=>l.a===a),dn=ls.filter(l=>S.lessons[l.id]).length;return`<section class="card acard" style="--ac:${A.c}"><h3>${ic(A.i,22)}${A.n}</h3><div><div class="bar" style="--ac:${A.c}"><i style="width:${dn/ls.length*100}%"></i></div><small class="muted">${dn} de ${ls.length} lecciones</small></div><div>${ls.map(l=>`<div class="lesson"><div><b>${l.t}</b><br><small class="muted">${l.min} min</small></div>${S.lessons[l.id]?`<span class="ok">${ic('check',22)}</span>`:`<a class="btn ghost sm" href="leccion.html?a=${l.id}">Abrir</a>`}</div>`).join('')}</div></section>`}).join('')}</div>`;
}

mountPage('cursos',coursesV);
