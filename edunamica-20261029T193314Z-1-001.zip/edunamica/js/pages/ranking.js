/* Página: ranking.html */
function rankV(el,arg){
  const tab=['sem','all','col'].includes(arg)?arg:'sem';
  const rows=leaderboard(tab),pos=rows.findIndex(r=>r.me)+1,top=rows.slice(0,3);
  const ms=weekStart();const endIn=Math.ceil((addDays(ms,7)-new Date())/36e5);
  const lg=leagueOf(weeklyXP());const nx=LEAGUES.find(l=>l[1]>weeklyXP());
  el.innerHTML=head('Ranking','Compite por XP. Cada semana el conteo se reinicia y sube tu liga.')+`
   <div class="card flat row" style="margin-bottom:18px;justify-content:space-between"><div><b style="font-family:var(--f-d);font-size:1.2rem">Liga ${lg[0]}</b><div class="muted">${nx?`Faltan ${nx[1]-weeklyXP()} XP para ${nx[0]}.`:'Estás en la liga más alta.'} La semana cierra en ${endIn>=24?Math.floor(endIn/24)+' días':endIn+' h'}.</div></div><div><b style="font-family:var(--f-d);font-size:1.6rem">#${pos}</b> <span class="muted">${tab==='sem'?'esta semana':tab==='all'?'histórico':'en tu colegio'}</span></div></div>
   <div class="tablist" role="tablist">${[['sem','Esta semana'],['all','Histórico'],['col','Mi colegio']].map(([k,l])=>`<button role="tab" aria-selected="${tab===k}" data-t="${k}">${l}</button>`).join('')}</div>
   ${rows.length<2?empty('Aún no hay compañeros de tu colegio','Escribe el nombre de tu colegio en tu perfil para aparecer con otros estudiantes.',`<a class="btn" href="perfil.html#editar">Editar perfil</a>`):`
   <div class="podium">${[1,0,2].map(k=>{const r=top[k];return r?`<div class="pod p${k+1}">${avatar(r.n,r.c,k===0?60:48)}<b>${esc(r.me?'Tú':r.n.split(' ')[0])}</b><small>${fmt(r.x)} XP</small><div class="blk">${k+1}</div></div>`:'<div></div>'}).join('')}</div>
   <div class="card" style="padding:6px 14px"><table class="rank"><tbody>${rows.slice(0,25).map((r,k)=>{const l=leagueOf(tab==='all'?r.x/6:r.x);return`<tr class="${r.me?'me':''}"><td class="pos">${k+1}</td><td><div class="who">${avatar(r.n,r.c,36)}<span>${esc(r.n)}${r.me?' (tú)':''}<small class="sch">${esc(r.school)}${r.city?', '+esc(r.city):''}</small></span></div></td><td><span class="league" style="color:${l[2]}">${ic('star',14)}${l[0]}</span></td><td style="text-align:right;font-weight:700">${fmt(r.x)} XP</td></tr>`}).join('')}</tbody></table></div>
   ${pos>25?`<p class="muted" style="margin-top:10px">Tu puesto es el ${pos}. Sigue sumando XP.</p>`:''}`}
   <p class="muted" style="margin-top:16px;font-size:.9rem">Los demás jugadores son ejemplos generados mientras se conecta el servidor del ranking real. Tu XP sí es el tuyo.</p>`;
  $$('[data-t]',el).forEach(b=>b.onclick=()=>{location.href='ranking.html?a='+b.dataset.t});
}


mountPage('ranking',rankV);
