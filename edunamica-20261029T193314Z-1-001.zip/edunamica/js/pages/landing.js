/* Página: landing.html - Rediseño dinámico con animaciones de scroll de alto impacto */
const DEMO = ['m3', 'c5', 'l3'];

function landing(root) {
  const logged = !!sessionUser();

  root.innerHTML = `
    <div class="lp">
      <div class="glow-orb glow-orb-1" aria-hidden="true"></div>
      <div class="glow-orb glow-orb-2" aria-hidden="true"></div>

      <header class="lp-head" id="main-nav">
        <div class="in">
          ${logo('index.html')}
          <nav class="lp-nav" aria-label="Secciones">
            <a href="#" data-scroll="como">Cómo funciona</a>
            <a href="#" data-scroll="funciones">Funciones</a>
            <a href="#" data-scroll="areas">Áreas</a>
            <a href="#" data-scroll="faq">Preguntas</a>
            <a href="#" data-scroll="equipo">Equipo</a>
          </nav>
          <div class="lp-actions">
            ${logged ? '' : '<a class="btn sm ghost" href="login.html">Iniciar sesión</a>'}
            <a class="btn sm lime" href="${logged ? 'dashboard.html' : 'registro.html'}">
              ${logged ? 'Ir a mi panel' : 'Empezar gratis'}
            </a>
          </div>
        </div>
      </header>

      <!-- HERO SECTION -->
      <section class="hero">
        <div class="wrap hero-grid">
          <div data-reveal="fade-up">
            <div class="hero-badge">
              <span class="badge-dot"></span>
              <span>Plataforma Adaptativa ICFES Saber 11</span>
            </div>
            <h1>
              Entrena el ICFES como si fuera tu <span class="hero-gradient-text">deporte favorito</span>.
            </h1>
            <p class="lead">
              Preguntas oficiales estilo Saber 11, retos diarios, rankings competitivos y un plan inteligente que se adapta a tus áreas débiles. Diseñado para grados 9, 10 y 11.
            </p>
            <div class="cta">
              <a class="btn lime lg" href="${logged ? 'dashboard.html' : 'registro.html'}">
                <span>${logged ? 'Seguir entrenando' : 'Crear mi perfil gratis'}</span>
                ${ic('arrow', 18)}
              </a>
              <a class="btn ghost lg" href="#" data-scroll="como">Ver cómo funciona</a>
            </div>

            <div class="hero-stat-row stagger-items" data-reveal="fade-up">
              <div class="counter-card">
                <b><span class="counter-num" data-target="5">5</span></b>
                <span>Áreas oficiales evaluadas</span>
              </div>
              <div class="counter-card">
                <b><span class="counter-num" data-target="50">50</span>+</b>
                <span>Preguntas con explicación</span>
              </div>
              <div class="counter-card">
                <b><span class="counter-num" data-target="100">100</span>%</b>
                <span>Nivel adaptativo por grado</span>
              </div>
              <div class="counter-card">
                <b><span class="counter-num" data-target="500">500</span></b>
                <span>Puntos meta global</span>
              </div>
            </div>
          </div>

          <!-- DEMO INTERACTIVA CON 3D TILT -->
          <div data-reveal="zoom-in" id="demo-wrapper">
            <div class="demo" id="demo" aria-label="Simulador de Pregunta de práctica">
              <div class="demo-glow-edge"></div>
            </div>
          </div>
        </div>
      </section>

      <!-- SECCIÓN CÓMO FUNCIONA -->
      <section class="sect alt" id="como">
        <div class="wrap">
          <div class="sect-h" data-reveal="fade-up">
            <h2>Tres pasos y ya estás entrenando</h2>
            <p>100% sin instalaciones. Tu progreso y datos se sincronizan y conservan en este dispositivo.</p>
          </div>
          <div class="steps stagger-items" data-reveal="fade-up">
            <div class="step">
              <h3>Haz el diagnóstico</h3>
              <p class="muted">Diez preguntas estratégicas, dos por área. Calculamos tu punto de partida real y tu puntaje proyectado de 0 a 500.</p>
            </div>
            <div class="step">
              <h3>Sigue tu plan adaptativo</h3>
              <p class="muted">Cada semana recibes bloques de práctica optimizados según tus áreas débiles y los días que tengas disponibles para estudiar.</p>
            </div>
            <div class="step">
              <h3>Practica y escala en ligas</h3>
              <p class="muted">Gana XP, mantén tu racha de días, sube de liga semanal y mide tu velocidad en simulacros con reloj oficial.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- SECCIÓN FUNCIONES BENTO GRID -->
      <section class="sect" id="funciones">
        <div class="wrap">
          <div class="sect-h" data-reveal="fade-up">
            <h2>Todo lo que necesitas para llegar con ventaja</h2>
            <p>Herramientas dinámicas construidas para transformar el estudio en un hábito constante.</p>
          </div>
          <div class="bento stagger-items" data-reveal="fade-up">
            <div class="b b1">
              ${ic('cal', 32)}
              <h3 style="font-size:1.65rem">Plan de estudio personalizado</h3>
              <p>Se recalcula en tiempo real con cada respuesta. Prioriza las áreas con mayor peso en el ICFES que necesitas reforzar.</p>
              <div class="mini-plan">
                <div><i style="--c:#9EE493"></i>Matemáticas: 8 preguntas de práctica</div>
                <div><i style="--c:#86BBD8"></i>Lectura crítica: lección de inferencias</div>
                <div><i style="--c:#F2B84B"></i>Reto diario de hoy: 5 de 5 completadas</div>
              </div>
            </div>
            <div class="b b2">
              ${ic('bolt', 28)}
              <h3>Retos diarios</h3>
              <p>Cinco preguntas nuevas cada día, una por área evaluada. Mantén tu racha encendida y multiplica tus monedas.</p>
            </div>
            <div class="b b3">
              ${ic('podium', 28)}
              <h3>Ranking y ligas</h3>
              <p>Compite sanamente de Bronce a Élite según tus puntos semanales y compárate con otros colegios.</p>
            </div>
            <div class="b b4">
              ${ic('trophy', 28)}
              <h3>Torneos relámpago</h3>
              <p>Desafíos rápidos de 20 segundos por pregunta y copas semanales de eliminación directa.</p>
            </div>
            <div class="b b5">
              ${ic('clock', 28)}
              <h3>Simulacros reales</h3>
              <p>Exámenes completos con temporizador regresivo, navegación de preguntas y retroalimentación final.</p>
            </div>
            <div class="b b6">
              ${ic('doc', 28)}
              <h3>Preguntas con año de referencia</h3>
              <p>Cada pregunta referencia el examen Saber 11 correspondiente (2019 a 2025). Adquieres el criterio exacto del ICFES.</p>
            </div>
            <div class="b b7">
              ${ic('chat', 28)}
              <h3>Asistente Edu y consejos</h3>
              <p>Tácticas de descarte, control de tiempo, manejo de ansiedad y consejos puntuales para cada materia.</p>
            </div>
          </div>
        </div>
      </section>

      <!-- SECCIÓN ÁREAS -->
      <section class="sect alt" id="areas">
        <div class="wrap">
          <div class="sect-h" data-reveal="fade-up">
            <h2>Las cinco áreas de la prueba Saber 11</h2>
            <p>Puntaje global sobre 500 puntos. Matemáticas, Lectura crítica, Sociales y Ciencias tienen peso 3. Inglés tiene peso 1.</p>
          </div>
          <div class="areas-row stagger-items" data-reveal="fade-up">
            ${AREA_KEYS.map(a => `
              <div class="area-tile" style="--ac:${AREAS[a].c}">
                <b>${AREAS[a].n}</b>
                <span>Ponderación: Peso ${AREAS[a].w}</span>
              </div>
            `).join('')}
          </div>
        </div>
      </section>

      <!-- MISIÓN Y VISIÓN -->
      <section class="sect alt">
        <div class="wrap">
          <div class="sect-h" data-reveal="fade-up">
            <h2>Pensado para estudiantes y colegios</h2>
            <p>Edunámica nace en la I.E. Francisco José de Caldas para motivar a los jóvenes de Colombia a conquistar su mejor futuro.</p>
          </div>
          <div class="cols2 stagger-items" data-reveal="fade-up">
            <div class="card" style="padding:28px">
              <h3 style="font-size:1.35rem;margin-bottom:12px;color:var(--brand)">Nuestra misión</h3>
              <p style="line-height:1.6;color:var(--muted)">
                Lograr que los estudiantes de grado 9, 10 y 11 consigan un puntaje destacado en las pruebas de Estado Saber 11, democratizando el acceso a preparación de alta calidad sin costo y fomentando la autodisciplina.
              </p>
            </div>
            <div class="card" style="padding:28px">
              <h3 style="font-size:1.35rem;margin-bottom:12px;color:var(--brand)">Nuestra visión</h3>
              <p style="line-height:1.6;color:var(--muted)">
                Consolidar un software educativo dinámico y de impacto nacional que adapte la dinámica de evaluación, impulse el ingreso a la educación superior y acompañe el éxito universitario.
              </p>
            </div>
          </div>
        </div>
      </section>

      <!-- PREGUNTAS FRECUENTES -->
      <section class="sect" id="faq">
        <div class="wrap" style="max-width:840px">
          <div class="sect-h" data-reveal="fade-up">
            <h2>Preguntas frecuentes</h2>
            <p>Todo lo que necesitas saber antes de empezar.</p>
          </div>
          <div class="faq" data-reveal="fade-up">
            <details>
              <summary>¿Cuesta algo usar Edunámica?</summary>
              <p>No, es 100% gratuito. Puedes registrarte, entrenar, realizar simulacros y consultar lecciones sin ningún costo.</p>
            </details>
            <details>
              <summary>¿Las preguntas son las del examen real?</summary>
              <p>Son preguntas fieles al formato, competencias y niveles de dificultad de Saber 11. Cada pregunta indica su año de referencia. Para consultar las pruebas publicadas por el ICFES, puedes acceder a la sección de Cuadernillos oficiales.</p>
            </details>
            <details>
              <summary>¿El puntaje estimado es el oficial del ICFES?</summary>
              <p>Es una proyección basada en tus respuestas y ponderada con los pesos oficiales de la prueba. Sirve para medir tu progreso continuo y calibrar tus tiempos.</p>
            </details>
            <details>
              <summary>¿Dónde se guarda mi progreso?</summary>
              <p>En este dispositivo y navegador a través de almacenamiento local seguro. Si borras la caché o datos del navegador, se reinicia.</p>
            </details>
            <details>
              <summary>¿Está afiliado al ICFES?</summary>
              <p>No. Edunámica es un proyecto independiente de impacto social y pedagógico creado por estudiantes de programación.</p>
            </details>
          </div>
        </div>
      </section>

      <!-- CTA FINAL BAND -->
      <section class="sect">
        <div class="wrap">
          <div class="cta-band" data-reveal="zoom-in">
            <div>
              <h2>Tu mejor puntaje empieza con la próxima pregunta.</h2>
              <p style="margin-top:10px;color:#D3E2EA;font-size:1.05rem">Únete a cientos de estudiantes que se preparan con constancia.</p>
            </div>
            <a class="btn lime lg" href="${logged ? 'dashboard.html' : 'registro.html'}" style="font-size:1.15rem;padding:16px 32px">
              ${logged ? 'Ir a mi panel' : 'Crear mi perfil gratis'}
            </a>
          </div>
        </div>
      </section>

      <!-- FOOTER -->
      <footer class="foot" id="equipo">
        <div class="wrap cols">
          <div>
            ${logo('index.html')}
            <p style="margin-top:12px;max-width:38ch;line-height:1.6">
              Proyecto del Técnico en Programación de Software, Institución Educativa Francisco José de Caldas, Santa Rosa de Cabal.
            </p>
          </div>
          <div>
            <h4>Equipo</h4>
            <ul>
              <li>Ewald Sánchez Badillo, dirección y backend</li>
              <li>Samuel Piedrahita Montes, backend</li>
              <li>Juan José Grisales, diseño y CSS</li>
              <li>José Fernando López Echeverry, diseño y CSS</li>
              <li>Sergio Romero Montoya, wireframes</li>
              <li>Eduardo García Ramírez, wireframes</li>
            </ul>
          </div>
          <div>
            <h4>Plataforma</h4>
            <ul>
              <li><a href="${logged ? 'dashboard.html' : 'registro.html'}">Crear perfil</a></li>
              <li><a href="#" data-scroll="como">Cómo funciona</a></li>
              <li><a href="#" data-scroll="faq">Preguntas frecuentes</a></li>
            </ul>
          </div>
        </div>
      </footer>
    </div>
  `;

  // Control de scroll suave
  $$('[data-scroll]', root).forEach(a => a.addEventListener('click', e => {
    e.preventDefault();
    const t = document.getElementById(a.dataset.scroll);
    if (t) t.scrollIntoView({ behavior: 'smooth' });
  }));

  // Header scroll & progress bar
  const navEl = $('#main-nav');
  const progBar = $('#scroll-progress');
  const handleScroll = () => {
    const sTop = window.scrollY || document.documentElement.scrollTop;
    const docH = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    if (progBar && docH > 0) {
      const pct = Math.min(100, Math.max(0, (sTop / docH) * 100));
      progBar.style.width = pct + '%';
    }
    if (navEl) {
      if (sTop > 24) navEl.classList.add('scrolled');
      else navEl.classList.remove('scrolled');
    }
  };
  window.addEventListener('scroll', handleScroll, { passive: true });
  handleScroll();

  // Scroll Reveal Observer con IntersectionObserver
  const revealEls = $$('[data-reveal]', root);
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach(el => observer.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('is-visible'));
  }

  // Animación de Contadores Numéricos al hacer scroll
  const counterEls = $$('.counter-num', root);
  if ('IntersectionObserver' in window) {
    const counterObserver = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const target = +el.dataset.target || 0;
          const duration = 1200;
          const startTime = performance.now();
          const step = now => {
            const progress = Math.min((now - startTime) / duration, 1);
            // Ease out cubic
            const current = Math.floor((1 - Math.pow(1 - progress, 3)) * target);
            el.textContent = current;
            if (progress < 1) requestAnimationFrame(step);
            else el.textContent = target;
          };
          requestAnimationFrame(step);
          obs.unobserve(el);
        }
      });
    }, { threshold: 0.5 });
    counterEls.forEach(el => counterObserver.observe(el));
  }

  // 3D Tilt interactivo en la tarjeta de demostración del Hero
  const demoWrap = $('#demo-wrapper');
  const demoCard = $('#demo');
  if (demoWrap && demoCard && window.matchMedia('(pointer: fine)').matches) {
    demoWrap.addEventListener('mousemove', e => {
      const rect = demoWrap.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      const rotateX = -(y / rect.height) * 12;
      const rotateY = (x / rect.width) * 12;
      demoCard.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
    });
    demoWrap.addEventListener('mouseleave', () => {
      demoCard.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
    });
  }

  // Lógica interactiva del simulador en vivo de preguntas
  let di = 0;
  const demo = () => {
    const q = QBY[DEMO[di % 3]], A = AREAS[q.a], ord = shuffle([0, 1, 2, 3]);
    const box = $('#demo');
    box.innerHTML = `
      <div class="demo-glow-edge"></div>
      <div class="demo-top">
        <span class="pill" style="--ac:${A.c};font-size:.88rem;padding:4px 12px">${A.n}</span>
        <span class="muted" style="font-size:.9rem;font-weight:600">Simulador en vivo</span>
      </div>
      ${q.p ? `<blockquote class="passage" style="font-size:.95rem">${PASS[q.p]}</blockquote>` : ''}
      <h2 class="qtext demo-q">${q.t}</h2>
      <div class="opts">
        ${ord.map((oi, p) => `
          <button class="opt" data-p="${p}">
            <span class="ltr">${'ABCD'[p]}</span>
            <span>${q.o[oi]}</span>
          </button>
        `).join('')}
      </div>
      <p class="qsrc" style="padding:14px 0 0">${srcLine(q)}</p>
      <div id="dfb" aria-live="polite"></div>
    `;

    $$('.opt', box).forEach(b => b.onclick = () => {
      const p = +b.dataset.p, ok = ord[p] === q.c;
      $$('.opt', box).forEach((x, pp) => {
        x.disabled = true;
        if (ord[pp] === q.c) x.classList.add('correct');
        else if (pp === p) x.classList.add('wrong');
        else x.classList.add('dim');
      });
      $('#dfb', box).innerHTML = `
        <div class="fb ${ok ? 'good' : 'bad'}" style="margin-top:14px">
          <strong>${ok ? '¡Excelente! Respuesta correcta.' : 'Casi acertaste.'}</strong>
          <p>${q.e}</p>
        </div>
        <div class="row" style="margin-top:14px">
          <a class="btn lime sm" href="${logged ? 'dashboard.html' : 'registro.html'}">
            ${logged ? 'Ir a mi panel' : 'Guardar mi progreso'}
          </a>
          <button class="btn ghost sm" id="dn">Probar otra pregunta</button>
        </div>
      `;
      $('#dn', box).onclick = () => {
        di++;
        demo();
      };
    });
  };
  demo();
}

landing($('#root'));
