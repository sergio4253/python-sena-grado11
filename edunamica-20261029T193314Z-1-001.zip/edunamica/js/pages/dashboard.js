/* Página: dashboard.html */
function dash(el){
  const u=S.user,gs=globalScore(),first=esc(u.name.split(' ')[0]),L=lvl(S.xp),wx=weeklyXP(),lg=leagueOf(wx);
  const wo=weakOrder(),weak=wo[0],dd=daysTo(u.exam),doneToday=S.daily.date===dayKey();
  const w=wc();
  const missions=missionList();
  const lb=leaderboard('sem').slice(0,5);const myPos=leaderboard('sem').findIndex(r=>r.me)+1;
  const hasData=total()>0;
  el.innerHTML=`<div class="hello pagehead"><div><h1>Hola, ${first}</h1><p>${dd!=null&&dd>=0?`Faltan <b>${dd}</b> días para tu examen. `:''}${hasData?`Tu área más débil ahora es <b>${AREAS[weak].n}</b>.`:'Empecemos por conocer tu punto de partida.'}</p></div></div>
  ${!S.diag?`<div class="banner">${ic('target',28)}<div class="grow"><b>Haz tu diagnóstico de 10 preguntas</b><p class="muted">Dos por área. Así calibramos la dificultad y tu plan.</p></div><a class="btn lime" href="practicar.html?a=diagnostico">Empezar diagnóstico</a></div>`:''}
  <div class="grid dash">
   <section class="card c-gauge"><h3>Puntaje estimado</h3>${gauge(gs,u.goal)}
    <p class="muted" style="text-align:center;margin-top:6px">${gs>=u.goal?'Ya alcanzaste tu meta. Súbela en tu perfil.':`Te faltan ${u.goal-gs} puntos para tu meta.`}</p>
    <div class="xpbar"><div class="row" style="justify-content:space-between;font-size:.9rem;margin-top:14px"><b>Nivel ${L}</b><span class="muted">${fmt(S.xp)} XP</span></div><div class="bar" style="margin-top:6px"><i style="width:${lvlPct()}%"></i></div></div></section>
   <section class="card big-cta c-daily"><div class="row" style="justify-content:space-between"><h3 style="color:#fff">${doneToday?'Reto de hoy completado':'Tu reto diario te espera'}</h3><span class="chip fire">${ic('flame',16)} ${streakNow()} días</span></div>
    <p>${doneToday?`Acertaste ${S.daily.ok} de ${S.daily.total}. Mañana hay uno nuevo.`:'Cinco preguntas, una por área. Cumple y suma 50 XP de bonus y monedas.'}</p>
    <a class="btn lime" href="retos.html">${doneToday?'Ver mis retos':'Jugar reto diario'}</a>
    <div class="row" style="margin-top:16px;gap:10px"><a class="btn ghost sm" style="color:#fff;border-color:#587080" href="practicar.html?a=${hasData?weak:'mix'}">${hasData?`Practicar ${AREAS[weak].n}`:'Practicar mixto'}</a><a class="btn ghost sm" style="color:#fff;border-color:#587080" href="simulacro.html">Hacer simulacro</a></div></section>
   <section class="card c-areas"><div class="row" style="justify-content:space-between"><h3>Tus áreas</h3><span class="muted" style="font-size:.9rem">Puntaje de 0 a 100</span></div>
    ${AREA_KEYS.map(a=>`<div class="arow"><span class="nm"><i class="dot" style="--ac:${AREAS[a].c}"></i>${AREAS[a].n}</span><div class="bar" style="--ac:${AREAS[a].c}"><i style="width:${areaScore(a)}%"></i></div><b class="v">${areaScore(a)}</b><a class="btn ghost sm" href="practicar.html?a=${a}">Practicar</a></div>`).join('')}</section>
   <section class="card c-miss"><h3>Misiones de la semana</h3>${missions.map(m=>missionHTML(m)).join('')}</section>
   <section class="card c-rank"><div class="row" style="justify-content:space-between"><h3>Ranking semanal</h3><a href="ranking.html">Ver todo</a></div>
    <p class="muted" style="margin-bottom:8px">Liga ${lg[0]}. Vas en el puesto ${myPos}.</p>
    <table class="rank"><tbody>${lb.map((r,k)=>`<tr class="${r.me?'me':''}"><td class="pos">${k+1}</td><td><div class="who">${avatar(r.n,r.c,30)}<span>${esc(r.me?'Tú':r.n.split(' ')[0])}</span></div></td><td style="text-align:right">${fmt(r.x)} XP</td></tr>`).join('')}</tbody></table></section>
   <section class="card c-act"><h3>Tu constancia</h3><p class="muted" style="margin-bottom:12px">Últimas 5 semanas. Más verde, más preguntas ese día.</p>${heat()}
    <div class="kv" style="margin-top:16px"><div><b>${total()}</b><span>Preguntas</span></div><div><b>${accAll()}%</b><span>Aciertos</span></div><div><b>${S.best}</b><span>Mejor racha</span></div><div><b>${S.sims.length}</b><span>Simulacros</span></div></div>
    ${S.sims.length>1?`<div style="margin-top:16px"><b>Evolución en simulacros</b>${spark(S.sims.map(s=>s.score))}</div>`:''}</section></div>`;
  $$('[data-claim]',el).forEach(b=>b.onclick=()=>claim(b.dataset.claim,el,()=>dash(el)));
}

mountPage('inicio',dash);
