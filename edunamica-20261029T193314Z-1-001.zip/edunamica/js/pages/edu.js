/* Página: edu.html */
function eduReply(t){
  t=t.toLowerCase();const wo=weakOrder(),w=wo[0],dd=daysTo(S.user.exam);
  const L=(h,x)=>`<a href="${h}">${x}</a>`;
  if(/hoy|estudiar|plan|empez|qué debo|que debo/.test(t))return`Hoy te recomiendo: 1) tu ${L('retos.html','reto diario')}, 2) diez preguntas de ${L('practicar.html?a='+w,AREAS[w].n)}, que es tu área con menor puntaje (${areaScore(w)}/100), y 3) revisar tus errores en ${L('practicar.html?a=repaso','Repaso')}.${dd!=null&&dd>=0?` Te faltan ${dd} días para el examen.`:''}`;
  if(/puntaje|global|500|cómo se calcula|como se calcula|peso/.test(t))return`El puntaje global va de 0 a 500. Se calcula con el promedio ponderado de las áreas: Matemáticas, Lectura crítica, Sociales y ciudadanas y Ciencias naturales pesan 3 cada una, e Inglés pesa 1. Tu estimado actual es ${globalScore()}.`;
  if(/nervio|ansied|miedo|estr[eé]s|calma/.test(t))return`Es normal sentir nervios. Ayuda: dormir bien, llegar con tiempo, respirar lento antes de empezar y leer cada pregunta sin prisa. Practicar con ${L('simulacro.html','simulacros')} reduce la sorpresa del día del examen. Si la ansiedad es muy fuerte, habla con un orientador de tu colegio.`;
  if(/mate|número|numero|álgebra|algebra|geometr/.test(t))return`En Matemáticas: 1) estima antes de calcular, 2) dibuja el problema, 3) comprueba reemplazando en la ecuación, 4) descarta opciones absurdas. Repasa la lección de ${L('leccion.html?a=lm1','porcentajes')} y practica ${L('practicar.html?a=mat','Matemáticas')}.`;
  if(/lectur|texto|leer|comprens|infer/.test(t))return`En Lectura crítica: lee primero la pregunta, luego el texto. Busca la tesis y los conectores de contraste. Desconfía de opciones muy extremas. Mira ${L('leccion.html?a=ll1','cómo encontrar la idea principal')}.`;
  if(/ingl|english|idioma/.test(t))return`En Inglés no traduzcas todo. Busca palabras clave y marcas de tiempo (since, for, yesterday). Aunque pesa 1 en el global, es un área donde subir rápido es posible. Prueba ${L('leccion.html?a=li1','los tiempos verbales')}.`;
  if(/social|ciudad|constituci|tutela/.test(t))return`En Sociales: identifica a los actores y sus intereses, y distingue hechos de opiniones. Aprende cuándo se usa cada mecanismo (tutela, acción popular, derecho de petición). Estudia ${L('leccion.html?a=ls1','la Constitución y sus mecanismos')}.`;
  if(/ciencia|f[ií]sica|qu[ií]mica|biolog/.test(t))return`En Ciencias: describe la gráfica o situación con tus palabras antes de ver las opciones. Repasa ${L('leccion.html?a=lc1','lectura de gráficas')} y ${L('leccion.html?a=lc2','energía, fuerza y movimiento')}.`;
  if(/tiempo|reloj|r[aá]pid|demor/.test(t))return`Para manejar el tiempo: no te quedes más de dos minutos en una pregunta. Márcala y sigue. Entrena en ${L('torneos.html','el torneo relámpago')} y en ${L('simulacro.html','simulacros')}.`;
  if(/racha|motiv|ganas|aburr/.test(t))return`Lo mejor es que sea pequeño: una pregunta al día mantiene tu racha (${streakNow()} días). Ponte una meta semanal en ${L('retos.html','misiones')} y sube de liga en el ${L('ranking.html','ranking')}.`;
  if(/error|fall|equivoc/.test(t))return S.review.length?`Tienes ${S.review.length} preguntas por repasar. Entra a ${L('practicar.html?a=repaso','Repaso')}. Cada error es información: lee la explicación y trata de decir con tus palabras por qué la opción correcta lo es.`:`Todavía no tienes errores guardados. Cuando falles una pregunta, quedará en tu repaso.`;
  return`Puedo ayudarte con: qué estudiar hoy, estrategias por área, el cálculo del puntaje global, manejo del tiempo, nervios y motivación. Por ahora respondo con la guía de estudio integrada de Edunámica. ¿Sobre qué quieres hablar?`;
}
function eduV(el){
  const first=esc(S.user.name.split(' ')[0]);
  el.innerHTML=head('Asistente Edu','Pregúntame por estrategias, tu plan o el puntaje.')+`<div class="chat"><div class="msgs" id="msgs" aria-live="polite"><div class="msg bot">Hola, ${first}. Soy Edu. Puedo orientarte con tu plan de estudio y con estrategias para cada área.</div></div>
   <div><div class="quick">${['¿Qué debo estudiar hoy?','¿Cómo se calcula el puntaje global?','Trucos de matemáticas','Estrategia de lectura crítica','¿Cómo manejo los nervios?','¿Cómo mejoro mi tiempo?'].map(x=>`<button>${x}</button>`).join('')}</div>
   <form class="chat-in" id="cf"><label class="sr" for="ci">Escribe tu pregunta</label><input type="text" id="ci" placeholder="Escribe tu pregunta" autocomplete="off"><button class="btn" aria-label="Enviar">${ic('send',18)}</button></form></div></div>`;
  const msgs=$('#msgs',el);
  const say=t=>{const m=document.createElement('div');m.className='msg me';m.textContent=t;msgs.appendChild(m);const b=document.createElement('div');b.className='msg bot';b.innerHTML=eduReply(t);msgs.appendChild(b);msgs.scrollTop=msgs.scrollHeight};
  $$('.quick button',el).forEach(b=>b.onclick=()=>say(b.textContent));
  $('#cf',el).onsubmit=e=>{e.preventDefault();const i=$('#ci',el),v=i.value.trim();if(!v)return;i.value='';say(v)};
}


mountPage('edu',eduV);
